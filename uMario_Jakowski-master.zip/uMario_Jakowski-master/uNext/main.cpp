#include "header.h"
#include "Core.h"

int main(int argc, char *argv[])
{
	CCore oCore;
	
	oCore.mainLoop();

	return 0;
}
